import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
// Import your process components
import Exploration from '/src/main/Exploration';
import Extraction from '/src/main/Extraction';
import Processing from '/src/main/Processing';
import Transportation from '/src/main/Transportation';
import Ventilation from '/src/main/Ventilation';
import Water from '/src/main/Water';
// Import GoogleGenerativeAI (if you have the correct API key)
import { GoogleGenerativeAI } from "@google/generative-ai";

ChartJS.register(ArcElement, Tooltip, Legend);

const CarbonFootprintApp = () => {
  const location = useLocation();
  const initialData = location.state?.emissionData || {
    exploration: 0,
    extraction: 0,
    processing: 0,
    transportation: 0,
    ventilation: 0,
    water: 0,
  };

  const [totalEmissions, setTotalEmissions] = useState(
    Object.values(initialData).reduce((a, b) => a + b, 0)
  );
  const [emissionsByProcess, setEmissionsByProcess] = useState(initialData);
  const [aiRecommendation, setAIRecommendation] = useState(''); // State for AI recommendation

  const emissionsRef = useRef(0);

  const handleUpdateEmissions = (emissions, process) => {
    emissionsRef.current += emissions;
    setTotalEmissions(emissionsRef.current);
    setEmissionsByProcess((prev) => ({
      ...prev,
      [process]: prev[process] + emissions,
    }));
  };

  useEffect(() => {
    const handleBeforeUnload = () => {
      localStorage.setItem('totalEmissions', '0');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  const pieData = {
    labels: ['Exploration', 'Extraction', 'Processing', 'Transportation', 'Ventilation', 'Water Management'],
    datasets: [
      {
        data: [
          emissionsByProcess.exploration,
          emissionsByProcess.extraction,
          emissionsByProcess.processing,
          emissionsByProcess.transportation,
          emissionsByProcess.ventilation,
          emissionsByProcess.water,
        ],
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#FF9F40', '#4BC0C0', '#9966FF'],
        hoverOffset: 20,
        borderWidth: 2,
        borderColor: '#fff',
      },
    ],
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    aspectRatio: 2,
    plugins: {
      legend: {
        position: 'right',
      },
      tooltip: {
        enabled: true,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        bodyFont: {
          size: 20,
        },
      },
    },
  };

  return (
    <div>
      <h1>Coal Mining Carbon Footprint Calculator</h1>
      <Exploration onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'exploration')} />
      <Extraction onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'extraction')} />
      <Processing onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'processing')} />
      <Transportation onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'transportation')} />
      <Ventilation onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'ventilation')} />
      <Water onUpdateEmissions={(emissions) => handleUpdateEmissions(emissions, 'water')} />
      <div>
        <h2>Total Carbon Footprint: {totalEmissions.toFixed(2)} kg CO2</h2>
      </div>
      <div>
        <h2>Process Composition contributing to Carbon Emission</h2>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
          <div style={{ width: '400px', height: '400px' }}>
            <Pie data={pieData} options={pieOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CarbonFootprintApp;
