import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Header Component
const Header = ({ handleProceed }) => (
  <div style={styles.header}>
    <div style={styles.logoSection}>
      <img src="logo.png" alt="logo" style={styles.logo} />
      <div>
        <h3>Suryakant Singh</h3>
        <p>Mining Operator</p>
      </div>
    </div>
    <h1>Enter Emission Data</h1>
    <button onClick={handleProceed} style={styles.proceedButton}>
      Proceed
    </button>
  </div>
);

// Carbon Emission Target Progress Component
const CarbonEmissionProgress = () => (
  <div style={styles.card}>
    <h3>Carbon Emission Target Progress</h3>
    {/* Circular Progress Chart goes here */}
    <div style={styles.circularChart}></div>
  </div>
);

// Performance Graph Component
const ResultPage = ({ emissionsByProcess }) => {
    const pieData = {
      labels: ['Exploration', 'Extraction', 'Processing', 'Transportation', 'Ventilation', 'Water Management'],
      datasets: [
        {
          data: [
            emissionsByProcess.exploration,
            emissionsByProcess.extraction,
            emissionsByProcess.processing,
            emissionsByProcess.transportation,
            emissionsByProcess.ventilation,
            emissionsByProcess.water,
          ],
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#FF9F40', '#4BC0C0', '#9966FF'],
          hoverOffset: 20,
          borderWidth: 2,
          borderColor: '#fff',
        },
      ],
    };
  
    const pieOptions = {
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        legend: {
          position: 'right',
        },
        tooltip: {
          enabled: true,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          bodyFont: {
            size: 20,
          },
        },
      },
    };
  
    return (
      <div>
        <h2>Total Carbon Footprint Composition</h2>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
          <div style={{ width: '400px', height: '400px' }}>
            <Pie data={pieData} options={pieOptions} />
          </div>
        </div>
      </div>
    );
  };

// Recent Entries Component
const RecentEntries = () => (
  <div style={styles.card}>
    <h3>Recent Entries</h3>
    <div>
      <p>Timestamp: 10th Oct 2024</p>
      <p>Activities: AI</p>
      <p>Quality: 50 tons</p>
    </div>
  </div>
);

// AI Predictions Component
const AIPredictions = () => (
  <div style={styles.card}>
    <h3>AI Predictions & Insights</h3>
    <p>Emissions are predicted to increase by 5% next month due to seasonal factors.</p>
  </div>
);

// Energy Efficiency Tips Component
const EnergyEfficiencyTips = () => (
  <div style={styles.card}>
    <h3>Energy Efficiency Tips</h3>
    <ul>
      <li>Switch to cleaner energy sources</li>
      <li>Optimize ventilation systems</li>
      <li>Use energy-efficient engines</li>
      {/* Add more tips here */}
    </ul>
  </div>
);

// Notifications Component
const Notifications = () => (
  <div style={styles.card}>
    <h3>Notifications</h3>
    <p>Emissions surpass safety thresholds or high-risk environmental conditions.</p>
  </div>
);

// Historical Data Viewer Component
const HistoricalDataViewer = () => (
  <div style={styles.card}>
    <h3>Historical Data Viewer</h3>
    <button style={styles.viewButton}>View only past records</button>
  </div>
);

// Main Component to Render the Page
const Dashboard = () => {
  const [emissionData, setEmissionData] = useState({
    exploration: 10,
    extraction: 20,
    processing: 30,
    transportation: 40,
    ventilation: 15,
    water: 25,
  });

  const navigate = useNavigate();

  const handleProceed = () => {
    // Navigate to CarbonFootprintApp with emission data
    navigate('/carbon-footprint', { state: { emissionData } });
  };

  return (
    <div style={styles.container}>
      <Header handleProceed={handleProceed} />
      <div style={styles.content}>
        <div style={styles.leftColumn}>
          <CarbonEmissionProgress />
          <Resultpage />
        </div>
        <div style={styles.rightColumn}>
          <RecentEntries />
          <AIPredictions />
          <EnergyEfficiencyTips />
          <Notifications />
          <HistoricalDataViewer />
        </div>
      </div>
    </div>
  );
};

// Inline CSS Styles
const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    color: '#333',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '20px',
    backgroundColor: '#e6e6e6',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
  },
  logo: {
    width: '50px',
    marginRight: '10px',
  },
  proceedButton: {
    padding: '10px 20px',
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  content: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '20px',
  },
  leftColumn: {
    width: '60%',
  },
  rightColumn: {
    width: '35%',
  },
  card: {
    backgroundColor: '#f9f9f9',
    padding: '20px',
    marginBottom: '20px',
    borderRadius: '10px',
  },
  circularChart: {
    width: '100px',
    height: '100px',
    backgroundColor: '#ddd', // Placeholder for circular chart
  },
  graph: {
    width: '100%',
    height: '200px',
    backgroundColor: '#eee', // Placeholder for graph
  },
  dropdown: {
    marginBottom: '10px',
  },
  viewButton: {
    padding: '10px 20px',
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
};

export default Dashboard;
